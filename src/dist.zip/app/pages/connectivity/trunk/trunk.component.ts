import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trunk',
  templateUrl: './trunk.component.html',
  styleUrls: ['./trunk.component.css']
})


export class TrunkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
